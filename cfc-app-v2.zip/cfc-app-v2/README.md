# CFC Store (v2) – Kotlin / Jetpack Compose

Modern rebuild of the original `CFC-App.apk` (`com.example.user.cfcapplication`, ~50 XML/Java activities).

Stack: Kotlin 2, Jetpack Compose + Material 3, Navigation Compose, Room, CameraX + ML Kit barcode scanning,
compileSdk/targetSdk 35, minSdk 26.

## Open it
Open this folder in Android Studio (Ladybug or newer), let it sync (it creates the Gradle wrapper), then Run.

## What is done
- Login -> Home grid (same 13 menu tiles as the old app) with Navigation
- Stock Take counting: location, category, camera barcode scan, qty, Confirm, Clear, Upload (stored offline in Room)
- Camera scanning replaces ZXing; permissions trimmed (no contacts, phone state, write settings or external storage)
- `CfcApi` interface replaces the app's direct SQL Server (jTDS) connection. `FakeCfcApi` lets it run now.

## What is left
Each remaining menu entry is a stub (`PlaceholderScreen`). Port order suggestion:
Perpetual, Receiving (DSD/Internal), Gap Check, Stock View, Damage Transfer, Edit Orders, Shelf Availability,
Download Master Files, then the rest. Each old Activity maps to one route + ViewModel.

The real database tables, queries and business rules were in the original Java code, which could not be
decompiled in this environment. Port them from your server/DB or the original source into a real `CfcApi`.

## Expiry dates and reminders
- In Stock Take, after scanning a product, tap "Set expiry date (optional)" then Confirm. The date is saved per product/location.
- A background check runs daily and at app start. Any item expiring within 1 month (or already expired) triggers one notification, then is marked as reminded. Change `REMIND_MONTHS_BEFORE` in `ExpiryReminder.kt` to alter the lead time.
- "Expiry Alerts" on the home screen lists all dates (red = expired, amber = within a month).
- Android 13+ asks for notification permission at launch; without it, reminders wait until it is granted.

## Product catalog
`app/src/main/assets/products.csv` holds the 221 items from Consolidated_Inventory_Stock_Taking_Sheet.pdf
(Perpetual 25624, FC Wennappuwa, Floor Stock, 2026-11-25): item code, name, pack size, selling price, system in-hand qty, category.
Stock Take finds items by scanning (the scanned value must equal the item code) or by typing a code/name.
The product card shows price, system qty and the variance against what you count.

## Registering barcodes later
- Scan an unknown barcode, then search the item by code or name and pick it: the app asks "Register barcode?" and links the scanned barcode to that item.
- Or search an item first, tap "Register barcode", then scan (or type) the barcode. An item can have several barcodes; "Remove" fixes mistakes.
- Next time that barcode is scanned the item opens directly. A barcode already linked to another item is refused.
- Links are stored on the device (Room table `barcode_map`); syncing them to a server comes with the real `CfcApi`.
