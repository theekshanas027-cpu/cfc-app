package com.cfc.store.ui.stocktake

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.cfc.store.CfcApp
import com.cfc.store.data.local.BarcodeDao
import com.cfc.store.data.local.BarcodeMap
import com.cfc.store.data.local.ExpiryDao
import com.cfc.store.data.local.ExpiryItem
import com.cfc.store.data.local.StockCount
import com.cfc.store.data.local.StockCountDao
import com.cfc.store.data.remote.CfcApi
import com.cfc.store.data.remote.Product
import com.cfc.store.data.remote.StockCountDto
import com.cfc.store.ui.scan.BarcodeScanner
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

data class CountUi(
    val categories: List<String> = emptyList(),
    val category: String = "",
    val location: String = "",
    val product: Product? = null,
    val message: String? = null,
    val query: String = "",
    val results: List<Product> = emptyList(),
    val barcodes: List<String> = emptyList(),   // barcodes registered for the shown product
    val registering: Boolean = false,           // next scan / typed barcode is registered to the shown product
    val pendingBarcode: String? = null,         // last scanned barcode that matched nothing
    val confirmLink: String? = null,            // asks the user to link pendingBarcode to the chosen product
    val uploading: Boolean = false,
)

class StocktakeViewModel(private val api: CfcApi, private val dao: StockCountDao, private val expiryDao: ExpiryDao, private val barcodeDao: BarcodeDao) : ViewModel() {
    private val _ui = MutableStateFlow(CountUi())
    val ui = _ui.asStateFlow()
    val pending = dao.observePending().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            val cats = runCatching { api.categories() }.getOrDefault(emptyList())
            _ui.update { it.copy(categories = cats, category = cats.firstOrNull().orEmpty()) }
        }
    }

    fun setLocation(v: String) = _ui.update { it.copy(location = v) }
    fun setCategory(v: String) = _ui.update { it.copy(category = v) }

    fun onBarcode(code: String) {
        viewModelScope.launch {
            val s = _ui.value
            val current = s.product
            if (s.registering && current != null) { register(current, code); return@launch }
            val mapped = barcodeDao.find(code)?.itemCode
            val p = runCatching { api.lookupProduct(mapped ?: code) }.getOrNull()
            if (p == null) {
                _ui.update { it.copy(pendingBarcode = code, message = "Barcode $code is not registered. Search the item by code or name to link it.") }
            } else showProduct(p)
        }
    }

    fun setQuery(q: String) {
        _ui.update { it.copy(query = q) }
        viewModelScope.launch {
            val r = if (q.isBlank()) emptyList() else runCatching { api.searchProducts(q) }.getOrDefault(emptyList())
            _ui.update { if (it.query == q) it.copy(results = r) else it }
        }
    }

    private suspend fun showProduct(p: Product) {
        val codes = barcodeDao.forItem(p.code).map { it.barcode }
        _ui.update {
            it.copy(product = p, results = emptyList(), query = "", barcodes = codes, registering = false,
                category = p.category.ifBlank { it.category }, message = null)
        }
    }

    /** Picked from search. If a scan just failed to match, offer to register that barcode to this item. */
    fun select(p: Product) {
        viewModelScope.launch {
            showProduct(p)
            _ui.value.pendingBarcode?.let { b -> _ui.update { it.copy(confirmLink = b) } }
        }
    }

    fun startRegister() = _ui.update { it.copy(registering = true, message = "Scan the product barcode, or type it below") }
    fun cancelRegister() = _ui.update { it.copy(registering = false, message = null) }
    fun registerTyped(code: String) { _ui.value.product?.let { p -> viewModelScope.launch { register(p, code) } } }
    fun confirmLink() {
        val s = _ui.value
        val p = s.product; val b = s.confirmLink
        if (p != null && b != null) viewModelScope.launch { register(p, b) }
    }
    fun dismissLink() = _ui.update { it.copy(confirmLink = null, pendingBarcode = null) }
    fun removeBarcode(code: String) {
        val p = _ui.value.product ?: return
        viewModelScope.launch {
            barcodeDao.remove(code)
            _ui.update { it.copy(barcodes = barcodeDao.forItem(p.code).map { m -> m.barcode }) }
        }
    }

    private suspend fun register(p: Product, raw: String) {
        val code = raw.trim()
        if (code.isEmpty()) return
        val existing = barcodeDao.find(code)
        if (existing != null && existing.itemCode != p.code) {
            _ui.update { it.copy(message = "Barcode already linked to item ${existing.itemCode}", confirmLink = null) }
            return
        }
        barcodeDao.upsert(BarcodeMap(barcode = code, itemCode = p.code))
        _ui.update {
            it.copy(barcodes = barcodeDao.forItem(p.code).map { m -> m.barcode }, registering = false,
                pendingBarcode = null, confirmLink = null, message = "Barcode registered for ${p.name}")
        }
    }

    fun confirm(qty: Double, expiry: LocalDate?) {
        val s = _ui.value
        val p = s.product ?: return
        if (s.location.isBlank()) { _ui.update { it.copy(message = "Enter a location first") }; return }
        viewModelScope.launch {
            dao.insert(StockCount(location = s.location, category = s.category, barcode = p.code, productName = p.name, qty = qty))
            if (expiry != null) {
                expiryDao.insert(ExpiryItem(barcode = p.code, productName = p.name, location = s.location, qty = qty, expiryEpochDay = expiry.toEpochDay()))
            }
            _ui.update { it.copy(product = null, registering = false, barcodes = emptyList(), message = null) }
        }
    }

    fun clear() = viewModelScope.launch { dao.clearPending() }

    fun upload() {
        viewModelScope.launch {
            _ui.update { it.copy(uploading = true, message = null) }
            val items = dao.pending()
            val result = runCatching {
                api.uploadStockCounts(items.map { StockCountDto(it.location, it.category, it.barcode, it.qty, it.countedAt) })
            }
            if (result.isSuccess) dao.markUploaded(items.map { it.id })
            _ui.update { it.copy(uploading = false, message = if (result.isSuccess) "Uploaded ${items.size} items" else "Upload failed") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StocktakeCountingScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as CfcApp
    val vm: StocktakeViewModel = viewModel(factory = viewModelFactory {
        initializer { StocktakeViewModel(app.api, app.db.stockCountDao(), app.db.expiryDao(), app.db.barcodeDao()) }
    })
    val ui by vm.ui.collectAsState()
    val pending by vm.pending.collectAsState()
    var qty by remember(ui.product) { mutableStateOf("1") }
    var catMenu by remember { mutableStateOf(false) }
    var expiry by remember(ui.product) { mutableStateOf<LocalDate?>(null) }
    var showPicker by remember { mutableStateOf(false) }

    if (showPicker) {
        val pickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { expiry = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Cancel") } },
        ) { DatePicker(state = pickerState) }
    }

    ui.confirmLink?.let { code ->
        AlertDialog(
            onDismissRequest = vm::dismissLink,
            title = { Text("Register barcode?") },
            text = { Text("Link scanned barcode $code to ${ui.product?.name} ${ui.product?.packSize}?") },
            confirmButton = { TextButton(onClick = vm::confirmLink) { Text("Register") } },
            dismissButton = { TextButton(onClick = vm::dismissLink) { Text("Not now") } },
        )
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Stock Take") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        })
    }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(ui.location, vm::setLocation, label = { Text("Location") }, singleLine = true, modifier = Modifier.weight(1f))
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { catMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(ui.category.ifBlank { "Category" })
                    }
                    DropdownMenu(catMenu, { catMenu = false }) {
                        ui.categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { vm.setCategory(c); catMenu = false }) }
                    }
                }
            }
            OutlinedTextField(
                ui.query, vm::setQuery, label = { Text("Item code or name") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            if (ui.results.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column {
                        ui.results.forEach { r ->
                            ListItem(
                                headlineContent = { Text("${r.name} ${r.packSize}") },
                                supportingContent = { Text(r.code) },
                                modifier = Modifier.clickable { vm.select(r) },
                            )
                        }
                    }
                }
            }
            BarcodeScanner(Modifier.fillMaxWidth().height(160.dp), onBarcode = vm::onBarcode)

            ui.product?.let { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("PRODUCT DETAILS", style = MaterialTheme.typography.labelMedium)
                        Text("${p.name} ${p.packSize}", style = MaterialTheme.typography.titleMedium)
                        Text("${p.code} · Rs ${"%.2f".format(p.price)} · System qty ${"%.0f".format(p.systemQty)}")
                        OutlinedTextField(
                            qty, { qty = it }, label = { Text("Qty") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        )
                        if (ui.barcodes.isEmpty()) {
                            Text("No barcode registered for this item", color = MaterialTheme.colorScheme.tertiary)
                        } else {
                            ui.barcodes.forEach { b ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Barcode $b", Modifier.weight(1f))
                                    TextButton(onClick = { vm.removeBarcode(b) }) { Text("Remove") }
                                }
                            }
                        }
                        if (ui.registering) {
                            var typed by remember { mutableStateOf("") }
                            OutlinedTextField(typed, { typed = it }, label = { Text("Or type barcode") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { vm.registerTyped(typed) }, enabled = typed.isNotBlank()) { Text("Save barcode") }
                                TextButton(onClick = vm::cancelRegister) { Text("Cancel") }
                            }
                        } else {
                            OutlinedButton(onClick = vm::startRegister) { Text(if (ui.barcodes.isEmpty()) "Register barcode" else "Add another barcode") }
                        }
                        qty.toDoubleOrNull()?.let { q ->
                            val diff = q - p.systemQty
                            Text(
                                if (diff == 0.0) "Matches system" else "Variance ${"%+.0f".format(diff)} vs system",
                                color = if (diff == 0.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            )
                        }
                        OutlinedButton(onClick = { showPicker = true }) {
                            Text(expiry?.let { "Expiry: $it" } ?: "Set expiry date (optional)")
                        }
                        Button(onClick = { vm.confirm(qty.toDoubleOrNull() ?: 0.0, expiry) }, enabled = qty.toDoubleOrNull() != null) { Text("Confirm") }
                    }
                }
            }
            ui.message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = vm::clear, enabled = pending.isNotEmpty()) { Text("Clear") }
                Button(onClick = vm::upload, enabled = pending.isNotEmpty() && !ui.uploading) { Text("Upload (${pending.size})") }
            }
            LazyColumn(Modifier.weight(1f)) {
                items(pending, key = { it.id }) { c ->
                    ListItem(
                        headlineContent = { Text(c.productName) },
                        supportingContent = { Text("${c.location} · ${c.category} · ${c.barcode}") },
                        trailingContent = { Text(c.qty.toString()) },
                    )
                }
            }
        }
    }
}
