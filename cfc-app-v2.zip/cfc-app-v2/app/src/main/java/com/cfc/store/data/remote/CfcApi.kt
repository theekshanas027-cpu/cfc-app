package com.cfc.store.data.remote

import android.content.Context
import com.cfc.store.data.catalog.ProductCatalog

data class Product(
    val code: String,
    val name: String,
    val packSize: String = "",
    val price: Double = 0.0,
    val systemQty: Double = 0.0,   // system in-hand quantity
    val category: String = "",
)
data class StockCountDto(val location: String, val category: String, val barcode: String, val qty: Double, val countedAt: Long)

/**
 * Replaces the old direct SQL Server (jTDS) access with a backend API.
 * Implement with Retrofit/Ktor; CatalogCfcApi serves the bundled product list so the app works offline.
 */
interface CfcApi {
    suspend fun login(user: String, password: String): Boolean
    suspend fun categories(): List<String>
    suspend fun lookupProduct(code: String): Product?
    suspend fun searchProducts(query: String): List<Product>
    suspend fun uploadStockCounts(items: List<StockCountDto>)
}

class CatalogCfcApi(context: Context) : CfcApi {
    private val catalog = ProductCatalog(context)
    override suspend fun login(user: String, password: String) = user.isNotBlank() && password.isNotBlank()
    override suspend fun categories() = catalog.categories
    override suspend fun lookupProduct(code: String) = catalog.find(code)
    override suspend fun searchProducts(query: String) = catalog.search(query)
    override suspend fun uploadStockCounts(items: List<StockCountDto>) { /* no server yet */ }
}
