package com.cfc.store.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.*
import com.cfc.store.ui.common.PlaceholderScreen
import com.cfc.store.ui.expiry.ExpiryScreen
import com.cfc.store.ui.home.HomeScreen
import com.cfc.store.ui.home.menu
import com.cfc.store.ui.login.LoginScreen
import com.cfc.store.ui.stocktake.StocktakeCountingScreen

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val STOCKTAKE = "stocktake"
    const val EXPIRY = "expiry"
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(nav, startDestination = Routes.LOGIN) {
        composable(Routes.LOGIN) {
            LoginScreen(onLoggedIn = {
                nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
            })
        }
        composable(Routes.HOME) { HomeScreen(onOpen = { nav.navigate(it) }) }
        composable(Routes.STOCKTAKE) { StocktakeCountingScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.EXPIRY) { ExpiryScreen(onBack = { nav.popBackStack() }) }
        // Every other menu entry gets a stub until it is ported.
        menu.filter { it.route != Routes.STOCKTAKE && it.route != Routes.EXPIRY }.forEach { item ->
            composable(item.route) { PlaceholderScreen(item.title) { nav.popBackStack() } }
        }
    }
}
