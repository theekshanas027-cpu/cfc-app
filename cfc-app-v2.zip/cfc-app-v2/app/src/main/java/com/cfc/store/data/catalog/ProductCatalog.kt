package com.cfc.store.data.catalog

import android.content.Context
import com.cfc.store.data.remote.Product

/** Product master loaded from assets/products.csv (exported from the stock audit sheet). */
class ProductCatalog(context: Context) {
    val products: List<Product> = context.assets.open("products.csv").bufferedReader().useLines { lines ->
        lines.drop(1).filter { it.isNotBlank() }.map { parse(it) }.toList()
    }
    private val byCode = products.associateBy { it.code.uppercase() }
    val categories: List<String> = products.map { it.category }.distinct()

    fun find(code: String): Product? = byCode[code.trim().uppercase()]

    /** Matches item code or any word of the name; exact code first. */
    fun search(query: String, limit: Int = 8): List<Product> {
        val words = query.trim().uppercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        return products.filter { p ->
            val hay = "${p.code} ${p.name} ${p.packSize}".uppercase()
            words.all { hay.contains(it) }
        }.sortedBy { if (it.code.equals(query.trim(), true)) 0 else 1 }.take(limit)
    }

    // code,name,pack,price,systemQty,category  (no quoted commas in this data set)
    private fun parse(line: String): Product {
        val c = line.split(",")
        return Product(code = c[0], name = c[1], packSize = c[2], price = c[3].toDouble(), systemQty = c[4].toDouble(), category = c[5])
    }
}
