package com.cfc.store.expiry

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.cfc.store.CfcApp
import com.cfc.store.MainActivity
import java.time.LocalDate
import java.util.concurrent.TimeUnit

const val CHANNEL_ID = "expiry"
/** Remind this many months before the expiry date. */
const val REMIND_MONTHS_BEFORE = 1L

fun createExpiryChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel(CHANNEL_ID, "Expiry reminders", NotificationManager.IMPORTANCE_DEFAULT)
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

/** Daily check, plus one check each time the app starts. */
fun scheduleExpiryChecks(context: Context) {
    val wm = WorkManager.getInstance(context)
    wm.enqueueUniquePeriodicWork(
        "expiry-daily", ExistingPeriodicWorkPolicy.KEEP,
        PeriodicWorkRequestBuilder<ExpiryWorker>(1, TimeUnit.DAYS).build(),
    )
    wm.enqueueUniqueWork("expiry-now", ExistingWorkPolicy.REPLACE, OneTimeWorkRequestBuilder<ExpiryWorker>().build())
}

class ExpiryWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val dao = (ctx.applicationContext as CfcApp).db.expiryDao()
        val limit = LocalDate.now().plusMonths(REMIND_MONTHS_BEFORE).toEpochDay()
        val due = dao.dueForReminder(limit)
        if (due.isEmpty()) return Result.success()

        val canNotify = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        // Not allowed to notify yet: leave items unreminded so the next run tries again.
        if (!canNotify || !NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return Result.success()

        val today = LocalDate.now().toEpochDay()
        val expired = due.count { it.expiryEpochDay < today }
        val names = due.take(3).joinToString(", ") { it.productName }
        val more = if (due.size > 3) " +${due.size - 3} more" else ""
        val title = if (expired > 0) "${due.size} items expired or expiring within a month" else "${due.size} items expire within a month"

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(names + more)
            .setStyle(NotificationCompat.BigTextStyle().bigText(names + more))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        @Suppress("MissingPermission")
        NotificationManagerCompat.from(ctx).notify(1001, n)
        dao.markReminded(due.map { it.id })
        return Result.success()
    }
}
