package com.cfc.store

import android.app.Application
import androidx.room.Room
import com.cfc.store.data.local.CfcDatabase
import com.cfc.store.data.local.MIGRATION_1_2
import com.cfc.store.data.local.MIGRATION_2_3
import com.cfc.store.data.remote.CfcApi
import com.cfc.store.data.remote.CatalogCfcApi
import com.cfc.store.expiry.createExpiryChannel
import com.cfc.store.expiry.scheduleExpiryChecks

class CfcApp : Application() {
    lateinit var db: CfcDatabase; private set
    val api: CfcApi by lazy { CatalogCfcApi(this) }   // swap for the real server implementation

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, CfcDatabase::class.java, "cfc.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
            .build()
        createExpiryChannel(this)
        scheduleExpiryChecks(this)
    }
}
