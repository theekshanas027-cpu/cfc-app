package com.cfc.store.ui.expiry

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.cfc.store.CfcApp
import com.cfc.store.data.local.ExpiryDao
import com.cfc.store.expiry.REMIND_MONTHS_BEFORE
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class ExpiryViewModel(private val dao: ExpiryDao) : ViewModel() {
    val items = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun delete(id: Long) { viewModelScope.launch { dao.delete(id) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpiryScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as CfcApp
    val vm: ExpiryViewModel = viewModel(factory = viewModelFactory { initializer { ExpiryViewModel(app.db.expiryDao()) } })
    val items by vm.items.collectAsState()
    val today = LocalDate.now()
    val soon = today.plusMonths(REMIND_MONTHS_BEFORE)

    Scaffold(topBar = {
        TopAppBar(title = { Text("Expiry Alerts") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        })
    }) { pad ->
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text("No expiry dates recorded yet. Add one when counting in Stock Take.")
            }
        } else LazyColumn(Modifier.padding(pad)) {
            items(items, key = { it.id }) { item ->
                val date = LocalDate.ofEpochDay(item.expiryEpochDay)
                val days = ChronoUnit.DAYS.between(today, date)
                val (status, color) = when {
                    date.isBefore(today) -> "Expired ${-days} d ago" to MaterialTheme.colorScheme.error
                    !date.isAfter(soon) -> "In $days d" to MaterialTheme.colorScheme.tertiary
                    else -> "In $days d" to MaterialTheme.colorScheme.onSurfaceVariant
                }
                ListItem(
                    headlineContent = { Text(item.productName) },
                    supportingContent = { Text("$date · ${item.location} · qty ${item.qty}") },
                    overlineContent = { Text(status, color = color) },
                    trailingContent = {
                        IconButton(onClick = { vm.delete(item.id) }) { Icon(Icons.Default.Delete, "Remove") }
                    },
                )
                HorizontalDivider()
            }
        }
    }
}
