package com.cfc.store.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

data class MenuItem(val title: String, val route: String)

/** Main menu entries taken from the original app's home screen. */
val menu = listOf(
    MenuItem("Capturing Barcodes", "capture_barcodes"),
    MenuItem("Check Shelf Availability", "shelf_availability"),
    MenuItem("Damage Transfer", "damage_transfer"),
    MenuItem("Download Master Files", "download_masterfiles"),
    MenuItem("Edit Orders", "edit_orders"),
    MenuItem("Gap Check", "gap_check"),
    MenuItem("Label Printing", "label_printing"),
    MenuItem("Perpetual", "perpetual"),
    MenuItem("Receiving", "receiving"),
    MenuItem("Roller Cage", "roller_cage"),
    MenuItem("Stock Take", "stocktake"),
    MenuItem("Expiry Alerts", "expiry"),
    MenuItem("Stock View", "stock_view"),
    MenuItem("Store Discount", "store_discount"),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("CFC Store") }) }) { pad ->
        LazyVerticalGrid(
            GridCells.Adaptive(150.dp),
            modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(menu) { item ->
                ElevatedCard(Modifier.fillMaxWidth().height(96.dp).clickable { onOpen(item.route) }) {
                    Box(Modifier.fillMaxSize().padding(8.dp), contentAlignment = Alignment.Center) {
                        Text(item.title, textAlign = TextAlign.Center, style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        }
    }
}
