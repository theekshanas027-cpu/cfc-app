package com.cfc.store.data.local

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "stock_count")
data class StockCount(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val location: String,
    val category: String,
    val barcode: String,
    val productName: String,
    val qty: Double,
    val countedAt: Long = System.currentTimeMillis(),
    val uploaded: Boolean = false,
)

/** A product batch with an expiry date. Kept after upload so reminders keep working. */
@Entity(tableName = "expiry_item")
data class ExpiryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val barcode: String,
    val productName: String,
    val location: String,
    val qty: Double,
    val expiryEpochDay: Long,
    val reminded: Boolean = false,
)

@Dao
interface StockCountDao {
    @Insert suspend fun insert(item: StockCount)
    @Query("SELECT * FROM stock_count WHERE uploaded = 0 ORDER BY countedAt DESC")
    fun observePending(): Flow<List<StockCount>>
    @Query("SELECT * FROM stock_count WHERE uploaded = 0")
    suspend fun pending(): List<StockCount>
    @Query("UPDATE stock_count SET uploaded = 1 WHERE id IN (:ids)")
    suspend fun markUploaded(ids: List<Long>)
    @Query("DELETE FROM stock_count WHERE uploaded = 0")
    suspend fun clearPending()
}

@Dao
interface ExpiryDao {
    @Insert suspend fun insert(item: ExpiryItem)
    @Query("SELECT * FROM expiry_item ORDER BY expiryEpochDay ASC")
    fun observeAll(): Flow<List<ExpiryItem>>
    /** Items expiring on or before [limitEpochDay] that have not been reminded yet (includes already expired). */
    @Query("SELECT * FROM expiry_item WHERE expiryEpochDay <= :limitEpochDay AND reminded = 0 ORDER BY expiryEpochDay")
    suspend fun dueForReminder(limitEpochDay: Long): List<ExpiryItem>
    @Query("UPDATE expiry_item SET reminded = 1 WHERE id IN (:ids)")
    suspend fun markReminded(ids: List<Long>)
    @Query("DELETE FROM expiry_item WHERE id = :id")
    suspend fun delete(id: Long)
}

/** A barcode registered by the user for a catalog item (one item can have several barcodes). */
@Entity(tableName = "barcode_map")
data class BarcodeMap(
    @PrimaryKey val barcode: String,
    val itemCode: String,
    val registeredAt: Long = System.currentTimeMillis(),
)

@Dao
interface BarcodeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(map: BarcodeMap)
    @Query("SELECT * FROM barcode_map WHERE barcode = :barcode") suspend fun find(barcode: String): BarcodeMap?
    @Query("SELECT * FROM barcode_map WHERE itemCode = :itemCode ORDER BY registeredAt") suspend fun forItem(itemCode: String): List<BarcodeMap>
    @Query("DELETE FROM barcode_map WHERE barcode = :barcode") suspend fun remove(barcode: String)
}

@Database(entities = [StockCount::class, ExpiryItem::class, BarcodeMap::class], version = 3, exportSchema = false)
abstract class CfcDatabase : RoomDatabase() {
    abstract fun stockCountDao(): StockCountDao
    abstract fun expiryDao(): ExpiryDao
    abstract fun barcodeDao(): BarcodeDao
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS barcode_map (" +
                "barcode TEXT NOT NULL, itemCode TEXT NOT NULL, registeredAt INTEGER NOT NULL, PRIMARY KEY(barcode))"
        )
    }
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS expiry_item (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, barcode TEXT NOT NULL, " +
                "productName TEXT NOT NULL, location TEXT NOT NULL, qty REAL NOT NULL, " +
                "expiryEpochDay INTEGER NOT NULL, reminded INTEGER NOT NULL)"
        )
    }
}
